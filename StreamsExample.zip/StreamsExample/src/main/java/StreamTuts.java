import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Employee{
    int empid;
    String empname;
    double sal;
};
 Employee(int i, String e, double sal){
    this.empid = i;
    this.empname = name;
    this.sal = sal;
};
public class StreamTuts {

    public void whenMapIdToEmployees_thenGetEmployeeStream() {

        Employee[] arrayOfEmps = {
                new Employee(1, "Jeff Bezos", 100000.0),
                new Employee(2, "Bill Gates", 200000.0),
                new Employee(3, "Mark Zuckerberg", 300000.0)
        };

        Stream.of(arrayOfEmps);
        Integer[] empIds = { 1, 2, 3 };

        Object employeeRepository = new Object();
        List<Employee> employees = Stream.of(empIds)
                .map(employeeRepository::findById)
                .collect(Collectors.toList());

        //assertEquals(employees.size(), empIds.length);
    }
}
