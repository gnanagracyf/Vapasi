import java.util.*;

public class TestStream {
    SortedMap<Integer, String> test = new TreeMap<Integer, String>();

    public TestStream(Integer grade,String name){
        List<String> names;
        names = test.containsKey(grade) ? Collections.singletonList(test.get(grade)) : new ArrayList<>();

    }

    public void display(){
        System.out.println(test);
        System.out.println(test.containsKey(2));
        System.out.println(test.get(2));
    }



    public static void main(String[] args){
        TestStream t = new TestStream(2,"Gracy");

        t.display();
    }
}
