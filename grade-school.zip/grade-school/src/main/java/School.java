import java.util.*;
import java.util.stream.*;

public class School {
    private String name;
    private int grade;

    SortedMap<Integer,List<String>> students = new TreeMap<>();
    public void add(String name, int i) {
        List<String> names = new ArrayList<>();
        names.add(name);
        students.put(2,names.stream().sorted().collect(Collectors.toList()));
    }

    public List<String> roster() {
        return students.values().stream().flatMap(x -> x.stream()).collect(Collectors.toList());
    }

    public List<String> grade(int i) {
        return null;
    }

    public String getName(){
        return this.name;
    }


}



