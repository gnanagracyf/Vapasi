import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)

public class AccountTest {


   @Test
    public void shouldhave10WhenAdded10RsIntoEmptyAccount() {
        Account account = new Account();
        account.setAccount(0);
        assertEquals(10,account.addMoney(10));
    }

  @Test
    public void ShouldHave0WhenWithdrawn100RsFromAccountWith100Rs() {
        Account account = new Account();
        account.setAccount(100);
        assertEquals(0,account.withdraw(100));

    }

    @Test
    public void ShouldSendEmailWhenOverDrafted() {
        EmailNotifier emailNotifier = mock(EmailNotifier.class);
        Account account = new Account(emailNotifier);
        account.setAccount(100);
        assertEquals(-10,account.withdraw(110));
        verify(emailNotifier).sendMail(eq("OverDrafted"));
    }
}
