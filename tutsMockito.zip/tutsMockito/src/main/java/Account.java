public class Account {
    int money;
    int balance = 0;
    EmailNotifier emailNotifier;

    public Account(EmailNotifier emailNotifier) {
        this.emailNotifier = emailNotifier;
    }

    public Account() {

    }


//    public Account(int money, EmailNotifier email){
//        this.money = money;
//        this.emailNotifier = email;
//    }

    public void setAccount(int money){
        this.money = money;
    }

    public int addMoney(int money) {
        this.money += money;
        return this.money;

    }

    public int withdraw(int money) {
        int balance = this.money;
        this.money = balance - money;
        if ( this.money < 0){
            //System.out.println("OverDrafted");
            emailNotifier.sendMail("OverDrafted");
        }
        return this.money;
    }
}
