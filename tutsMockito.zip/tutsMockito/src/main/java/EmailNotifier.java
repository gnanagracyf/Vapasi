public class EmailNotifier {

    public void sendMail(String overDrafted){
        System.out.println(overDrafted);
    }


}
