public class GrudgerBot extends PlayerType {
    int score;
    String name;

    public void setName(){
        this.name = "GrudgerBot";
    }

    //public void getMove() {
     //   Moves moves = new Cooperate();
//        if ( Player.moves == Cheat){
//            moves = new Cheat();
//        }
   // }
}
