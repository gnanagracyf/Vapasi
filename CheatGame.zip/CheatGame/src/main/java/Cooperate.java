public class Cooperate extends Moves {

    public Cooperate(PlayerType player1, PlayerType player2) {
        super(player1, player2);
    }

    public void setScore(PlayerType player1,PlayerType player2){
        player1.score--;
        player2.score+= 3;
    }
}
