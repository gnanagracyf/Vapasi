public class EvilBot extends PlayerType {
    int score;
    String name;

    public void setName(){
        this.name = "EvilBot";
    }
//    public void setMove() {
//        Moves moves = new Cheat();
//    }
}
