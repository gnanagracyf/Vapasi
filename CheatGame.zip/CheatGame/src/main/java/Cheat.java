public class Cheat extends Moves {

    public Cheat(PlayerType player1, PlayerType player2) {
        super(player1, player2);
    }
    public void setScore(PlayerType player1,PlayerType player2){
        //Does nothing..can remove comfortably
        player1.score=0;
        player2.score=0;
    }
}
