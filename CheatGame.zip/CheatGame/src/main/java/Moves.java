public class Moves {

    PlayerType player1;
    PlayerType player2;

    public Moves(PlayerType player1, PlayerType player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    public void setScore(PlayerType player1,PlayerType player2){
    }

}
