public class PlayerType {
    int score;
    String name;
    Moves moves;
    Play play;

    public void setName(){
        this.name = "Player";
    }

    public String getName(){
        return this.name;
    }


    public void setScore(int score){
        this.score = score;
    }

    public int getScore(){
        return this.score;
    }

    public void setMove() {
        moves
    }
}
