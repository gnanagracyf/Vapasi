public class Play {

    PlayerType player1;
    PlayerType player2;
    Moves move;

    public void chooseMove(int choice){
        if (choice == 0){

        }
        else
            move = new Cheat(player1,player2);
    }
}
