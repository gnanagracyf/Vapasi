public class Player extends PlayerType{
    int score;

    public void setMoves() {
    }
}
