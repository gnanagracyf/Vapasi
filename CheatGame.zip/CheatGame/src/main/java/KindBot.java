public class KindBot extends PlayerType {
    String name;
    int score;

    public void setName(){
        this.name = "KindBot";
    }
    public String getName(){
        return this.name;
    }

  public void setMove() {
      Moves moves = new Cooperate(player1 ,player2 );
  }
}

