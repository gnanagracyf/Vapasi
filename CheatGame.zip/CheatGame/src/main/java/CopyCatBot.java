public class CopyCatBot extends PlayerType {
    int score;
    String name;

    public void setName(){
        this.name = "CopyCatBot";
    }

//    public void getMove() {
//        int round = 0;
//        if ( round == 1) {
//            Moves moves = new Cooperate();
//        }
//        else{
//            //Copy players moves
//        }
//    }
}
