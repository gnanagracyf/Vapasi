import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {


    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        Player player = new Player();
        int moveChoice;
        int maxRound = 7;
        int minRound = 3;
        Random rand = new Random();
        int noOfRound = rand.nextInt((maxRound - minRound) + 1) + minRound;
        System.out.println("No. of Rounds to Play :" + noOfRound);

        List<PlayerType> bottype = new ArrayList();
        PlayerType kindBot = new KindBot();
        kindBot.setName();
        PlayerType evilBot = new EvilBot();
        evilBot.setName();
        PlayerType copyCatBot = new CopyCatBot();
        copyCatBot.setName();
        PlayerType gruderBot = new GrudgerBot();
        gruderBot.setName();

        bottype.add(kindBot);
        bottype.add(evilBot);
        bottype.add(copyCatBot);
        bottype.add(gruderBot);


        for (PlayerType bot:bottype){
            System.out.println("Bot Type Playing against User : "+ bot.getName());
            for (int i =0 ; i <= noOfRound-1 ; i++){
                System.out.println("Enter the choice of move for player Cooperate/Cheat [0/1] :");
                moveChoice = input.nextInt();

                player.play.chooseMove(moveChoice);

                System.out.println(" Player 1 score :" +   player.getScore());

                bot.setMove();
                //calculate total and display
            }
        }


    }
}
