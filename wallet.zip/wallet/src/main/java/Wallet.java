public class Wallet {
    int money = 0;
    int balance = 0;

    public Wallet(int money){
        this.money = money;
    }
    public void addMoney(int money) {
        this.balance += money;
    }
}
