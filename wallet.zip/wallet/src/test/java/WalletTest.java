//import .junit.Test;

public class WalletTest {

    @Test
    public void shouldHave10RsWhenAdded10IntoEmptyWallet(){
        Wallet wallet = new Wallet(0);
        assertequals(10,wallet.addMoney(10));
    }


}