import java.io.CharArrayWriter;
import java.util.HashMap;
import java.util.List;

class RnaTranscription {

    String transcribe(String dnaStrand) {

        String rnaStrand = "";
        HashMap<String, String> map = new HashMap<>();
        map.put("G","C");
        map.put("C","G");
        map.put("T","A");
        map.put("A","U");
        if (dnaStrand == ""){
            rnaStrand = "";
        }
        else if ( dnaStrand.length() == 1){
            rnaStrand = map.get(dnaStrand);
        }
        else{
            for ( int i = 0; i < dnaStrand.length(); i++) {
                //System.out.println(dnaStrand.toCharArray()[i]);
                rnaStrand = rnaStrand + map.get(Character.toString(dnaStrand.toCharArray()[i]));
            }
        }
        return  rnaStrand;
    }

}

