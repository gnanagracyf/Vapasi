//import javafx.css.Match;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class WordCount{
    HashMap<String , Integer> phrase(String input){
        HashMap<String, Integer> wordCount = new HashMap<>();

        Pattern p = Pattern.compile("[a-zA-Z0-9]+");
        Matcher m = p.matcher(input);
        while (m.find()) {
            System.out.println(m.group());
            int count = 1;
            String word = m.group().toLowerCase();

            if (wordCount.containsKey(word)) {
                count = wordCount.get(word);
                count += 1;
            }
            wordCount.put(word,count);

        }
        return wordCount;
    }
 }