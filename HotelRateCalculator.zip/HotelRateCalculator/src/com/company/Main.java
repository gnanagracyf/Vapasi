package com.company;

import java.util.*;
import java.util.stream.Stream;


public class Main {


    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the Customer Query <customer_type>:<Rating_Preferred>:<no_of_days>: ");
        String query = input.nextLine();

        String[] inputTokens = query.split(":");
        System.out.println(Arrays.toString(inputTokens));

        String customerType = inputTokens[0];
        Integer ratingGiven = Integer.parseInt(inputTokens[1]);
        Integer noOfDays = Integer.parseInt(inputTokens[2]);

        Hotel LakeWood = new Hotel("LakeWood",3,15);
        Hotel BridgeWood = new Hotel("BridgeWood",4,20);
        Hotel RidgeWood = new Hotel("RidgeWood",5,25);
        Hotel RiverView  = new Hotel("RiverView",3,0);


        List<Hotel> hotels =  Arrays.asList(LakeWood, BridgeWood, RidgeWood, RiverView);

        Discount regular = new Discount("Regular",0);
        Discount rewards = new Discount("Rewards",15);
        Discount regularmoredays = new Discount("Regular",10); //Add 10% more if staying more than two days
        Discount rewardsmoredays = new Discount("Rewards",25); //Add 15 + 10 if staying more than two days


        List<Discount> discounts =  Arrays.asList(regular,rewards,regularmoredays,rewardsmoredays); //no new...coz its static method

        Main m = new Main();
        Quotation q = new Quotation();
        Integer quote = q.calculateQuotation(hotels, discounts,customerType, ratingGiven);
        quote = quote * noOfDays;

        System.out.println(quote);

    }




}
