package com.company;

public class Discount {
    String customerType;
    Integer discountRate;


    public Discount(String customerType, Integer discountRate){
        this.customerType = customerType;
        this.discountRate = discountRate;
    }

    Integer getDiscountRate(){
        return discountRate;
    }

    String getCustomerType(){
        return customerType;
    }

}
