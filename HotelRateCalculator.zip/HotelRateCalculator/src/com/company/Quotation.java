package com.company;

import java.util.*;

public class Quotation {

    public Integer calculateQuotation(List<Hotel> hotels, List<Discount> discounts, String customerType,Integer ratingGiven){

        Integer discountAmount = null;
        Integer rateAfterDiscount = null;

        Iterator discItr = discounts.iterator();
        while (discItr.hasNext()) {
            Discount element = (Discount)discItr.next();
            if (customerType.equals(element.getCustomerType())){
                discountAmount = element.getDiscountRate();
            }
        }

        Iterator itr = hotels.iterator();
        String hotelName = null;
        Integer addCharge;
        Integer quote = null;

        List<Hotel> hotelsforRating = new ArrayList<Hotel>();

        Integer minAddCharge = null;

        while(itr.hasNext()) {
            Hotel element = (Hotel) itr.next();
            if (ratingGiven == element.getRating()) {
                hotelsforRating.add(element);
            }
        }

        Hotel minHotel = null;
        //Collections.sort(hotelsforRating);
        Iterator itrMin = hotelsforRating.iterator();
        while(itrMin.hasNext()) {
            Hotel elt = (Hotel) itr.next();
            Integer minCharges = elt.getAdditionalCharges();
            if ( elt.getAdditionalCharges() < minAddCharge) {
                minHotel = elt;
            }
        }


        addCharge = minHotel.getAdditionalCharges();
        Integer perDayAmount = minHotel.perDayCharge();
        rateAfterDiscount = discountAmount;

        return rateAfterDiscount;

    }
}
