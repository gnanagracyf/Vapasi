package com.company;

public class Tariff {
    Integer rating;
    Integer rate;

    public Tariff(Integer rating, Integer rate){
        this.rating = rating;
        this.rate = rate;
    }

    Integer getRating(){
        return this.rating;
    }

    Integer getRate(){
        return  this.rate;
    }

}
