package com.company;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Hotel {
    String name;
    Integer rating;
    Integer additionalCharges;
    //Tariff taf; //Hotel can know tariffs...collaborator

    public Hotel(String name, Integer rating, Integer additionalCharges) {
        this.name = name;
        this.rating = rating;
        this.additionalCharges = additionalCharges;
    }

    public String getName() {
        return this.name;
    }

    public Integer getRating() {
        return this.rating;
    }

    public Integer getAdditionalCharges() {
        return this.additionalCharges;
    }


    public Integer getRatefromTariff(){
        Integer rate = null;
        Tariff threeStar = new Tariff(3, 110);
        Tariff fourStar = new Tariff(4, 160);
        Tariff fiveStar = new Tariff(5, 220);

        List<Tariff> tariffs = new ArrayList<Tariff>();
        tariffs.add(threeStar);
        tariffs.add(fourStar);
        tariffs.add(fiveStar);

        Iterator itr = tariffs.iterator();

        while(itr.hasNext()) {
            Tariff element = (Tariff) itr.next();
            if (this.rating == element.getRating()){
                rate = element.getRate();
            }
        }
        return rate;
    }

    public Integer perDayCharge() {
        Integer rateFromTariff = getRatefromTariff();
        Integer totalAmount = this.additionalCharges  + rateFromTariff;
        return totalAmount;
    }
}
