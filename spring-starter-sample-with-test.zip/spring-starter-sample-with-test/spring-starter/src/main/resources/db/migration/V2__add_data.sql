insert into authors values (1, 'J.K. Rowling');
insert into authors values (2, 'Jane Austen');
insert into authors values (3, 'George RR Martin');
insert into authors values (4, 'Martin Fowler');
insert into authors values (5, 'Chetan Bhagat');

insert into books values(1, 'Harry Potter and the Sorcerers Stone', '978-3-16-148410-0', 1);
insert into books values(2, 'Harry Potter and the Chamber of Secrets','978-1-56619-909-4', 1);
insert into books values(3, 'Harry Potter and the Prisoner of Azkaban','1-4028-9462-7', 1);
insert into books values(4, 'Harry Potter and the Goblet of Fire','978-1-4028-9462-6', 1);
insert into books values(5, 'Pride and Prejudice', '0136091814', 2);
insert into books values(6, 'Sense and Sensibility', '9780136091813', 2);
insert into books values(7, 'Emma', '9781433805622', 2);
insert into books values(8, 'Game of Thrones', '9781172328963', 3);
insert into books values(9, 'Winds of Winter', '9780321652898', 3);
insert into books values(10, 'Refactoring', '9780415922227', 4);
