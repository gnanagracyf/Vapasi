public class StockService {
    public double getPrice(Stock stock) {
        return 0;
    }

}
