public class EvilBotStrategy implements MovesStrategy {

    @Override
    public void move(int prevPlayerChoice, int roundNo) {
        MovesType movesType = new MovesType();
    }
}
