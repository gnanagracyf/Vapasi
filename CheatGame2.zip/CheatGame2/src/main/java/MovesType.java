public class MovesType {

    int playerScore;
    int opponentScore;

    public MovesType(){
        setOpponentScore();
        setPlayerScore();
    }

    public void setPlayerScore(){
        this.playerScore = 0;
    }

    public void setOpponentScore(){
        this.opponentScore = 0;
    }

    public int getPlayerScore(){
        return this.playerScore;
    }

    public int getOpponentScore(){
        return this.opponentScore;
    }
}
