public class KindBotStrategy implements MovesStrategy {

    MovesType movesType = new MovesType();

    @Override
    public void move(int prevPlayerChoice, int roundNo) {
        movesType = new Cooperate();
    }
}
