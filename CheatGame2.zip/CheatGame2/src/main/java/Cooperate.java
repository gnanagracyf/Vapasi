public class Cooperate extends MovesType{

    public Cooperate(){
        super();
    }

    public void setPlayerScore(){
        this.playerScore = -1;
    }

    public void setOpponentScore(){
        this.opponentScore = 3;
    }
}