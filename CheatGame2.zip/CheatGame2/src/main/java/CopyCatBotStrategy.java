public class CopyCatBotStrategy implements MovesStrategy {

    MovesType movesType = new MovesType();

    @Override
    public void move(int prevPlayerChoice, int roundNo) {
        if (roundNo == 2)
            movesType = new Cooperate();
        else
            movesType = (prevPlayerChoice == 0) ? new Cooperate() : new MovesType();

    }
}
