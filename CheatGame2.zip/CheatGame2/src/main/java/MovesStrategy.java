public interface MovesStrategy {
    public void move(int prevPlayerChoice, int roundNo);
}
