import java.util.ArrayList;
import java.util.Arrays;

import java.util.List;
import java.util.Scanner;

public class Game {

    //Allow then to play..for each round
    //calculate scores for player and bot in each round...
    MovesStrategy movesStrategy;

    public void playGame() {
        Round round = new Round();
        List<MovesStrategy> botList = Arrays.asList(new KindBotStrategy(), new EvilBotStrategy(), new CopyCatBotStrategy(), new GrudgerStrategy());
        for (MovesStrategy bot:botList) {
            movesStrategy = bot;
            round.playRounds(bot);
        }
    }

    public static void main(String[] args){
        Game game = new Game();
        game.playGame();
    }
}
