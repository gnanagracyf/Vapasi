import java.util.Random;
import java.util.Scanner;

public class Round {

    int noOfRounds;
    int playerMove;
    int totalplayerScore = 0;
    int botScore = 0;

    MovesType movesType = new MovesType();


    public int getNoOfRounds() {
        //Get a random number generated for each game...for no. of rounds...
        //Store player moves ..
        System.out.println("Enter the number of rounds to play:");
        Scanner input = new Scanner(System.in);
        int noOfRounds = input.nextInt();
        return noOfRounds;
    }

    public void settotalplayerScore(int totalplayerScore){
        this.totalplayerScore = totalplayerScore;
    }

    public int gettotalplayerScore(){
        return  this.totalplayerScore;
    }

    public int getPlayerMove(){
        return this.playerMove;
    }

    public void playRounds(MovesStrategy bot){
        noOfRounds = getNoOfRounds();
        for (int i =0 ; i < noOfRounds ; i ++) {
            System.out.println("Enter the move for the player to play (Cooperate = 0/Cheat = 1) for round no " + Integer.toString(i + 1));
            Scanner input = new Scanner(System.in);
            playerMove = input.nextInt();

            movesType = (playerMove == 0)? new Cooperate() : new MovesType();
            int score = movesType.getPlayerScore() + gettotalplayerScore();
            settotalplayerScore(score);
            botScore += movesType.getOpponentScore();

            i++;
            if ( i <= noOfRounds) {
                bot.move(getPlayerMove(),gettotalplayerScore());
                botScore += movesType.getPlayerScore();
                int score1 = movesType.getOpponentScore() + gettotalplayerScore();
                settotalplayerScore(score1);
            }
        }
        System.out.println("Player Score: " + gettotalplayerScore());
        System.out.println("Bot Score: "+ botScore);
    }

}
