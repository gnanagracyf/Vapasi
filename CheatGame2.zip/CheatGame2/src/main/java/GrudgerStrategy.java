public class GrudgerStrategy implements MovesStrategy {
    MovesType movesType = new MovesType();

    @Override
    public void move(int prevPlayerChoice, int roundNo) {
        if (roundNo == 2)
            movesType = new Cooperate();
        else {
            if (prevPlayerChoice == 1)
                movesType = new MovesType();
        }
    }
}
