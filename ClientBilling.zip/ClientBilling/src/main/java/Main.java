import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the client details like Alpha-US-70.64-P1: "); // Any client per hour is Rs.100
        String clientDetails = input.nextLine();
        System.out.println("Client Details entered : " + clientDetails);


    }

}
