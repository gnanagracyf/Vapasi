public interface DayEntryTypes {
    int getHours();
}
