import java.awt.event.ActionListener;
import java.util.List;

public class Client {
    String clientName;
    String clientCountry;
    int convertionRate;
    List<String> projects;

    int getProjectHours(String clientName,  String convertionRate, List<String> projects){ // for individual client...for individual proj
        //for each project in each client ..call employee.addeachprojecthours
        return 0;
    }
}
