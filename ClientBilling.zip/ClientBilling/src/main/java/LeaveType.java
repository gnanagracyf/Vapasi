public class LeaveType implements DayEntryTypes {
    @Override
    public int getHours() {
        return 0;
    }
}
