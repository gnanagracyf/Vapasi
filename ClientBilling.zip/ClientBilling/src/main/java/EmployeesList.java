import java.util.ArrayList;
import java.util.List;

public class EmployeesList {
    TimeSheet employee = new TimeSheet();
    e1 = new Employee();

    List<TimeSheet> = ArrayList<TimeSheet>{e1,e2,e3};
}
