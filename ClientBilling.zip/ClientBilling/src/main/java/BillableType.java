public class BillableType implements  DayEntryTypes{
    @Override
    public int getHours() {
        return 0;
    }
}
