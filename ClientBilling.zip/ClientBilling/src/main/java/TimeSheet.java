import java.util.List;

public class TimeSheet {
    String name;
    List<String> dayentry; // can make this a class

    //Split details like P1-8-B or P1-8-NB or LEAVE ....add it to each project in a list...
    int addeachprojecthours(List<String> dayentry){

    }
}
