package com.booking;

public class DiscountEngine {

    private final CustomerTypeDiscount customerTypeDiscount;
    private final StayTypeDiscount stayTypeDiscount;

    public DiscountEngine(CustomerTypeDiscount customerTypeDiscount, StayTypeDiscount stayTypeDiscount) {

        this.customerTypeDiscount = customerTypeDiscount;
        this.stayTypeDiscount = stayTypeDiscount;
    }

    public double getDiscountPercentage(int noOfDays, CustomerType customerType) {
        Double discountPercentage = customerTypeDiscount.getDiscountPercentage(customerType);
        Double discountPercentage1 = stayTypeDiscount.getDiscountPercentage(noOfDays);
        return discountPercentage + discountPercentage1;
    }
}
