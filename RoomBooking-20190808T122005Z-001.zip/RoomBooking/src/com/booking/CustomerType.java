package com.booking;

public enum CustomerType {
    REGULAR, REWARDS
}
