package com.booking;

import java.util.ArrayList;
import java.util.List;

public class HotelRepository {

    private List<Hotel> hotels;

    public HotelRepository() {
        hotels = new ArrayList<>();
    }

    public void addHotels(Hotel hotel) {
        hotels.add(hotel);
    }

    public Hotel getHotel(Rating rating) {
        return hotels.stream().filter(hotel -> hotel.getRating().equals(rating)).findFirst().get();
    }
}
