package com.booking;

public class Hotel {

    private HotelType hotelType;

    private String name;
    private Double extraCharge;

    public Hotel(HotelType hotelType, String name, Double extraCharge) {
        this.hotelType = hotelType;
        this.name = name;
        this.extraCharge = extraCharge;
    }

    public Rating getRating() {
        return hotelType.getRating();
    }


    public Double getRate() {
        return hotelType.getRate() + extraCharge;
    }

    public String getName() {
        return name;
    }
}



