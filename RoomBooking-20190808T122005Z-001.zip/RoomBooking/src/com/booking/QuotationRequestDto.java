package com.booking;

public class QuotationRequestDto {

    private final CustomerType customerType;
    private final Rating rating;
    private final int noOfDays;

    public QuotationRequestDto(CustomerType customerType, Rating rating, int noOfDays) {

        this.customerType = customerType;
        this.rating = rating;
        this.noOfDays = noOfDays;
    }

    public Rating getRating() {
        return rating;
    }

    public int getNoOfDays() {
        return noOfDays;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }
}
