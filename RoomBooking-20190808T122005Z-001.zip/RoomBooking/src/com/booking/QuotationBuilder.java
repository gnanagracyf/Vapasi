package com.booking;

public class QuotationBuilder {

    private PricingEngine pricingEngine;
    private HotelRepository hotelRepository;

    public QuotationBuilder(PricingEngine pricingEngine, HotelRepository hotelRepository) {
        this.pricingEngine = pricingEngine;
        this.hotelRepository = hotelRepository;
    }

    public Quotation build(QuotationRequestDto requestDto) {
        Hotel hotel = hotelRepository.getHotel(requestDto.getRating());
        Double price = pricingEngine.getPrice(hotel, requestDto.getNoOfDays(), requestDto.getCustomerType());

        return new Quotation(hotel, price);
    }
}
