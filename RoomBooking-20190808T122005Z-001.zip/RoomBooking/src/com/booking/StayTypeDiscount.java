package com.booking;

public class StayTypeDiscount {
    public Double getDiscountPercentage(int noOfDays) {
        return noOfDays > 2 ? 0.10 : 0;
    }
}
