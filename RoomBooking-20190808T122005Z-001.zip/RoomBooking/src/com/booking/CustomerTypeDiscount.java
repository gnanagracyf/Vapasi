package com.booking;

public class CustomerTypeDiscount {

    public Double getDiscountPercentage(CustomerType customerType) {
        return customerType == CustomerType.REGULAR ? 0 : 0.15;
    }
}
