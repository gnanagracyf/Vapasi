package com.booking;

public class HotelType {

    private Rating rating;

    private Double rate;

    public Double getRate() {
        return rate;
    }

    public Rating getRating() {
        return rating;
    }

    public HotelType(Rating rating, Double rate) {
        this.rating = rating;
        this.rate = rate;
    }
}
