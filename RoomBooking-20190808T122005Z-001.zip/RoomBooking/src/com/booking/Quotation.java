package com.booking;

public class Quotation {
    private Hotel hotel;

    private Double amount;

    public Quotation(Hotel hotel, Double amount) {
        this.hotel = hotel;
        this.amount = amount;
    }

    public String generate() {
        return hotel.getName() + "  " + amount;
    }
}


