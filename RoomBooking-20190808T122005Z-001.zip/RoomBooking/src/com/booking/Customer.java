package com.booking;

public class Customer {

    private String customerName;

    private CustomerType customerType;
}

