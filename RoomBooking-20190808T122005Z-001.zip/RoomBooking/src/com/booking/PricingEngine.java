package com.booking;

public class PricingEngine {

    private DiscountEngine discountEngine;

    public PricingEngine(DiscountEngine discountEngine){
        this.discountEngine = discountEngine;
    }

    public Double getPrice(Hotel hotel, int noOfDays, CustomerType customerType) {
        double priceWithoutDiscounts = hotel.getRate() * noOfDays;
        Double discountPercentage = discountEngine.getDiscountPercentage(noOfDays, customerType);
        return priceWithoutDiscounts - priceWithoutDiscounts * discountPercentage;
    }
}

