package com.booking;

public class Main {

    public static void main(String[] args) {

        HotelType threeStarType = new HotelType(Rating.THREE, 110.0);
        HotelType fourStarType = new HotelType(Rating.FOUR, 160.0);
        HotelType fiveStarType = new HotelType(Rating.FIVE, 220.0);

        HotelRepository hotelRepository = new HotelRepository();
        hotelRepository.addHotels(new Hotel(threeStarType, "LakeWood", 15.0));

        PricingEngine pricingEngine = new PricingEngine(new DiscountEngine(new CustomerTypeDiscount(), new StayTypeDiscount()));
        QuotationBuilder quotationBuilder = new QuotationBuilder(pricingEngine, hotelRepository);

        Quotation quotation = quotationBuilder.build(new QuotationRequestDto(CustomerType.REGULAR, Rating.THREE, 2));

        System.out.println(quotation.generate());
    }
}
