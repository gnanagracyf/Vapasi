package com.booking;

public enum Rating {
    THREE, FOUR, FIVE
}
