import java.util.Scanner;

public class HandCricket {

    public static void main ( String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the Scores to be Chased: ");
        int scoresToBeChased = input.nextInt();

        Scanner input1 = new Scanner(System.in);
        System.out.println("Enter the no. of Overs: ");
        int overs = input1.nextInt();

        Scanner input2 = new Scanner(System.in);
        System.out.println("Enter the type of Batsman Normal/Hitman/TailEnder [ 0 or 1 or 2]: ");
        int batsmanType = input2.nextInt();

        Scanner input3 = new Scanner(System.in);
        System.out.println("Enter the type of Bowler Normal/PartTime [ 0 or 1 ]: ");
        int bowlerType = input3.nextInt();

        Match match = new Match();
        match.Play(scoresToBeChased,overs,batsmanType,bowlerType);

    }
}

