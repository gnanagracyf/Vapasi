public abstract class Scores {
    Decision decision = null;
    int totalScore;

    public Scores(int totalScore){
        this.totalScore = totalScore;
    }
    public void getDecision(){
        decision.matchResult();
    };
}
