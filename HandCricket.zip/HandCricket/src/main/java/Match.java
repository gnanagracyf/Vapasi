public class Match {
    public int noOfBalls = 6;
    Player batsman = new Batsman();
    Player bowler = new Batsman();
    ScoreBoard scoreBoard = new ScoreBoard();
    ScoresTypeFactory scoresTypeFactory = new ScoresTypeFactory();
    Scores scores;


    public void Play(int scoresToBeChased,int overs, int batsmanType, int bowlerType){

        int totalBalls = scoresToBeChased * overs;
        int totalScore = 0;

        if ( batsmanType == 1) batsman = new Hitman();

        for ( int ball=0 ; ball < totalBalls ; ball++){
            int batsmanScore = batsman.generateScore(noOfBalls);
            int bowlerScore = bowler.generateScore(noOfBalls);
            System.out.println("Batsman score is "+ batsmanScore);
            System.out.println("Bowler score is "+ bowlerScore);
            totalScore = scoreBoard.calculateTotalScore(batsmanScore, totalScore);

            scores = scoresTypeFactory.getScoresType(batsmanScore,bowlerScore,scoresToBeChased,totalScore,bowlerType,batsmanType);
            totalScore = scores.totalScore;
            scores.getDecision();
        }
    }
}
