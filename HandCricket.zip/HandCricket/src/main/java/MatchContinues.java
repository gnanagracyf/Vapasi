public class MatchContinues implements Decision {
    @Override
    public void matchResult() {
    }
}
