public class ScoresTypeFactory {

    Scores scores = null;
    public Scores getScoresType(int batsmanScore, int bowlerScore, int target, int totalScore, int bowlerType, int batsmanType) {
        if ( (batsmanType == 2) && (( batsmanScore%2==0 & bowlerScore%2==0 ) || (batsmanScore%3==0 & bowlerScore%3==0) )){
            scores = new TailEnderScoreStrategy(totalScore);
        }
        else if (batsmanScore == bowlerScore) {
            if (bowlerType == 1 ){
                scores.totalScore = totalScore - batsmanScore;
                scores = new PartTimeBowlerScoreStrategy(scores.totalScore);
            }
            else {
                scores = new EqualScoresStrategy(totalScore);
            }
        }
        else if (totalScore >= target) {
            scores = new TargetAchievedStrategy(totalScore);
        }
        else {
            scores = new NoStrategy(totalScore);
        }
        return scores;
    }
}

