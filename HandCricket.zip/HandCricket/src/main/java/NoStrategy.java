public class NoStrategy extends Scores {

    public NoStrategy(int totalScore) {
        super(totalScore);
        decision = new MatchContinues();
    }
}