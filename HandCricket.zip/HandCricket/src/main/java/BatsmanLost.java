public class BatsmanLost implements Decision {
    @Override
    public void matchResult() {
        System.out.println("Batsman Lost!!!");
        System.exit(0);
    }
}
