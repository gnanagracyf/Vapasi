public interface Player {
    public int generateScore(int noOfBalls);
}
