import java.util.Random;

public class Batsman implements Player{

    public int generateScore(int noOfBalls){
        Random rand = new Random();
        int score = rand.nextInt(noOfBalls+1);
        return score;
    }
}
