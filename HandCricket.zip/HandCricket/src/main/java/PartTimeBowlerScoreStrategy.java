public class PartTimeBowlerScoreStrategy extends Scores {
    public PartTimeBowlerScoreStrategy(int totalScore) {
        super(totalScore);
        decision = new MatchContinues();
    }
}
