import java.util.Random;

public class Hitman implements Player {
    public int generateScore(int noOfBalls){
        int[] runsToChoose = {0,4,6};
        Random rand = new Random();
        int score = runsToChoose[rand.nextInt(runsToChoose.length)];

        return score;
    }
}
