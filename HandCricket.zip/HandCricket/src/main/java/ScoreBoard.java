public class ScoreBoard {

    public int calculateTotalScore(int batsmanScore, int totalScore){
        totalScore += batsmanScore;
        return totalScore;
    }
}
