public class TailEnderScoreStrategy extends Scores {
    public TailEnderScoreStrategy(int totalScore) {
        super(totalScore);
        decision = new BatsmanLost();
    }
}
