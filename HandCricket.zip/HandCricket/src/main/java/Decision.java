public interface  Decision {

    public void matchResult();
}
