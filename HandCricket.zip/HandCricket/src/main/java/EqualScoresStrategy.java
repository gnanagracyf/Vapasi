public class EqualScoresStrategy extends Scores {

    public EqualScoresStrategy(int totalScore) {
        super(totalScore);
        decision = new BatsmanLost();
    }
}
