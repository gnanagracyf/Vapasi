public class BatsmanWon implements Decision {
    @Override
    public void matchResult() {
        System.out.println("Batsman won !!!");
        System.exit(0);
    }
}
