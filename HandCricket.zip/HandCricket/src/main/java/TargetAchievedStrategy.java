public class TargetAchievedStrategy extends Scores {

    public TargetAchievedStrategy(int totalScore ){
        super(totalScore);
        decision = new BatsmanWon();
    }
}
