import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashMap;

class ProteinTranslator {

    List<String> translate(String rnaSequence) {

        System.out.println(rnaSequence);

        HashMap<String, String> map = new HashMap<String, String>();
        map.put("AUG","Methionine");
        map.put("UUU","Phenylalanine");
        map.put("UUC","Phenylalanine");
        map.put("UUA","Leucine");
        map.put("UUG","Leucine");
        map.put("UCU","Serine");
        map.put("UCC","Serine");
        map.put("UCA","Serine");
        map.put("UCG","Serine");
        map.put("UAU","Tyrosine");
        map.put("UAC","Tyrosine");
        map.put("UGU","Cysteine");
        map.put("UGC","Cysteine");
        map.put("UGG","Tryptophan");


        String Codons = " ";
        String protein_value = " ";
        int rnaSeqLen = rnaSequence.length();
        List<String>  protein = new ArrayList<>();

        String[] stopSeq =  {"UAA","UAG","UGA"};
        List<String> stopList = Arrays.asList(stopSeq);

        for (int i = 0; i < rnaSeqLen ; i++)
        {
            Codons = rnaSequence.substring(i,Math.min(i+3, rnaSeqLen));
            System.out.println(Codons);
            if (stopList.contains(Codons)) {
                break;
            }
            else{
                protein_value = map.get(Codons);
                protein.add(protein_value);
                i += 2;
            }

        }

        return protein;
    }
}