package com.vapasi.springstarter.controller;

import com.vapasi.springstarter.repository.AuthorRepository;
import com.vapasi.springstarter.repository.BookRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class BookControllerTest {

    @InjectMocks
    BookController bookController;

    @Mock
    BookRepository bookRepository;

    @Mock
    AuthorController authorController;

    @Mock
    AuthorRepository authorRepository;

    @Test
    public void shouldGetAllBooks() {
        assertEquals(200, bookController.getBooks().getStatusCodeValue());
        verify(bookRepository).findAll();
    }

    @Test
    public void shouldGetHello() {
        assertEquals(200,bookController.getHello().getStatusCodeValue());
    }

    @Test
    public void shouldGetObeBookDetailsForAGivenId() {
        Integer id = 1;
        assertEquals(200,bookController.getBookByID(id).getStatusCodeValue());
        verify(bookRepository).findById(id);
    }

    @Test
    public void shouldGetBookDetailsForGivenAuthor() {
        String authorname = "J.K. Rowling";
        assertEquals(200,authorController.getAuthorByName(authorname).getStatusCodeValue());
        verify(authorRepository).findAllByauthorname(authorname);
    }

}