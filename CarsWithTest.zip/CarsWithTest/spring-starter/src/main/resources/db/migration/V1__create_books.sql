CREATE TABLE authors (
    authorid int not null primary key auto_increment,
    authorname varchar
);

CREATE TABLE books (
    bookid int not null primary key auto_increment,
    bookname varchar,
    isbn varchar,
    authorid integer references authors(authorid)
);
