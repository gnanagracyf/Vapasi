package com.vapasi.springstarter.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;


@Entity
@Table(name="authors")

public class Author {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Getter
    private Integer authorid;

    @Column(name="authorname")
    @Getter
    private String authorname;

    @OneToMany(mappedBy = "author")
    private List<Book> books;
}
