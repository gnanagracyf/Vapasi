package com.vapasi.springstarter.controller;

import com.vapasi.springstarter.model.Author;
import com.vapasi.springstarter.repository.AuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@RestController
public class AuthorController {
    @Autowired
    AuthorRepository authorRepository;

    @GetMapping("/authors")
    public ResponseEntity<List<Author>> getauthors(){
        List<Author> authors = authorRepository.findAll();
        return ResponseEntity.ok().body(authors);
    }

    @GetMapping("/author")
    public ResponseEntity<Object> getAuthorByName(@RequestParam(name="authorname") String authorname) {
        Author author = authorRepository.findAllByauthorname(authorname);
        return ResponseEntity.ok().body(author);
    }
}
