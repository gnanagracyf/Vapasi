package com.vapasi.springstarter.model;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "books")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "bookid")
    @Getter
    private Integer bookid;


    @Column(name = "bookname")
    @Getter
    private String bookname;

    @Column(name="isbn")
    @Getter
    private String isbn;

    @ManyToOne
    @JoinColumn(name="authorid",referencedColumnName = "authorid")
    @Getter
    private Author author;
}
