package com.vapasi.springstarter.controller;

import com.vapasi.springstarter.model.Author;
import com.vapasi.springstarter.model.Book;
import com.vapasi.springstarter.repository.AuthorRepository;
import com.vapasi.springstarter.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

//@RestController
@Controller
public class BookController {

    @Autowired
    BookRepository bookRepository;
    @Autowired
    AuthorRepository authorRepository;

//    @GetMapping("/hello")
//    public ResponseEntity<String> getHello(){
//        return ResponseEntity.ok().body("Hello Ria");
//    }

//    @GetMapping("/hello")
//    public String getHello(Model model){
//        model.addAttribute("name","Ria");
//        return "book";
//    }


//    @GetMapping("/books")
//    public ResponseEntity<List<Book>> getBooks() {
//        List<Book> books = bookRepository.findAll();
//        return ResponseEntity.ok().body(books);
//    }

    @GetMapping("/books")
    public String getBooks(Model model) {
        List<Book> books = bookRepository.findAll();
        Book book = bookRepository.findAll().get(0);
        //model.addAttribute("name","Ria");
        //model.addAttribute("isbn",)
        //model.addAttribute("book",books.get(0));
        model.addAttribute("book",book);
        model.addAttribute("books",books);
        return "book"; //html template name
    }


    //localhost:8080/book?id=1
//    @GetMapping("/book/id")
//    public ResponseEntity<Optional<Book>> getBookByID(@RequestParam(value="id")  Integer id) {
//        Optional<Book> book = bookRepository.findById(id);
//        return ResponseEntity.ok().body(book);
//    }
//
//    //Get Books with author name
//    @GetMapping("/book/authorname")
//    public ResponseEntity<List<Book>> getBookByAuthor(@RequestParam(value="authorname") String authorname) {
//        Author author = authorRepository.findAllByauthorname(authorname);
//        List<Book> books = bookRepository.findAllByAuthor(author);
//        return ResponseEntity.ok().body(books);
//    }
}
