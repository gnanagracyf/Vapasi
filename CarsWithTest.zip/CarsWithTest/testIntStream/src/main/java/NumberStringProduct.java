import java.util.Arrays;
import java.util.stream.Stream;

class NumberStringProduct {
    String input = "012345679";

    public void cal(){
        char[] digitsFromInput = input.toCharArray();
        int[] newIntArr = new int[digitsFromInput.length];
        for (int i = 0; i< digitsFromInput.length ; i++){
            newIntArr[i] = Character.getNumericValue(digitsFromInput[i]);
        }

        for (int i = 0; i< digitsFromInput.length ; i++){
            System.out.println(newIntArr[i]);
        }

    }


    public static void main(String[] args) {
        // convert the string input to individual numbers and then get input how many digits n then product it
        NumberStringProduct num = new NumberStringProduct();
        num.cal();
    }
}
