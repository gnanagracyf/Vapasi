package com.register.registerUser.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
@Entity
@Table(name="users")
@Getter
@NoArgsConstructor
public class User {
        @Id
        @Column
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int id;

        @Column
        private String name;

        @Column
        private String email;

        @Column
        private String encryptedPassword;
}
