import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

char[] nums = new char[100];

class LargestSeriesProductCalculator {
    LargestSeriesProductCalculator(String inputNumber) {
          //nums = Arrays.stream(new char inputNumber.toCharArray();
        char[] nums = inputNumber.toCharArray();

    }
    long calculateLargestProductForSeriesLength(int numberOfDigits) {
        //product of 2 digits..digits got as input and inputNumber is a series entered..
        return 0;
    }
}
