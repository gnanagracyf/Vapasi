public class NumberStringPRoduct<digitsFromInput> {
    String input = "012345679";

    public static void cal(){
        char[] digitsFromInput = input.toCharArray();
        for (int i = 0; i< digitsFromInput.length ; i++){
            System.out.print(digitsFromInput[i]);
        }

    }
    public static void main() {
        // convert the string input to individual numbers and then get input how many digits n then product it
        cal();
    }
}
