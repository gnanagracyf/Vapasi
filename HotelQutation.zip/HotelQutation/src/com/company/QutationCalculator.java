package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class QutationCalculator {

    List<Hotel> hotels = new ArrayList<Hotel>();
    List<Tariff> tari = new ArrayList<Tariff>();
    void setTariff(){
        Tariff threeStar = new Tariff(3,110);
        Tariff fourStar = new Tariff(4,160);
        Tariff fiveStar = new Tariff(5,220);
        tari.add(threeStar);
        tari.add(fourStar);
        tari.add(fiveStar);
    }

    void setHotelList(){
        Hotel LakeWood = new Hotel ("LakeWood",3,15);
        Hotel BridgeWood = new Hotel("BridgeWood",4,20);
        Hotel RidgeWood = new Hotel("RidgeWood",5,25);
        hotels.add(LakeWood);
        hotels.add(BridgeWood);
        hotels.add(RidgeWood);
    }

    void setCustomer() {
        Customer c1 = new Customer("Regular", 1, 3);
        Customer c2 = new Customer("Regular", 3, 3);
        Customer c3 = new Customer("Rewards", 1, 4);

    }

    Integer calculateQuotation (Customer c,List<Hotel> hotels,List<Tariff> tas){
        System.out.println(h.hotelName);
        System.out.println(c.customerType);
        Integer ratingPreffered = c.hotelRatingNeeded;

        for (tass : tas){

        }


        return 0;
    }


}