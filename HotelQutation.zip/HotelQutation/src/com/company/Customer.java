package com.company;

public class Customer{
    String customerType;
    Integer noOfDays;
    Integer hotelRatingNeeded;

    public Customer(String customerType, Integer noOfDays, Integer hotelRatingNeeded){
        this.customerType  = customerType;
        this.noOfDays = noOfDays;
        this.hotelRatingNeeded = hotelRatingNeeded;
    }

    String getCustomerType(Customer c){
        return c.customerType;
    }

    Integer getNoOfDays(Customer c){
        return c.noOfDays;
    }

    Integer getHotelRatingNeeded(Customer c){
        return c.hotelRatingNeeded;
    }

}