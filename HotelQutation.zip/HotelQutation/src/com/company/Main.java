package com.company;

import java.util.Currency;

public class Main {

    public static void main(String[] args) {

	}
}

