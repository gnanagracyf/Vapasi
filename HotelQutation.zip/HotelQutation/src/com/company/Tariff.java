package com.company;

public class Tariff{
    Integer rating;
    Integer rate;

    Tariff(Integer rating, Integer rate){
        this.rating = rating;
        this.rate = rate;
    }

    Integer getRating(Tariff t){
        return t.rating;
    }

    Integer getRate(Tariff t){
        return t.rate;
    }
}