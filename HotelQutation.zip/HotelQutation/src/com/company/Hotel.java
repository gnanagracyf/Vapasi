package com.company;

public class Hotel{
    String hotelName;
    Integer hotelRating;
    Integer additionalCharge;

    public Hotel(String hotelName, Integer hotelRating, Integer additionalCharge){
        this.hotelName = hotelName;
        this.hotelRating = hotelRating;
        this.additionalCharge = additionalCharge;
    }

    String getHotelName(Hotel h){
        return h.hotelName;
    }

    Integer getHotelRating(Hotel h){
        return h.hotelRating;
    }

    Integer getAdditionalCharge(Hotel h){
        return h.additionalCharge;
    }

}