public class RedHeadDuck extends Duck {
    public RedHeadDuck() {
        flyBehaviour = new FlySlow();
        swimBehaviour = new CanSwim();
        }

}
