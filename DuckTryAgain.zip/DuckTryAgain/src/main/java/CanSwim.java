public class CanSwim implements SwimBehaviour {
    @Override
    public void swim() {

    }
}
