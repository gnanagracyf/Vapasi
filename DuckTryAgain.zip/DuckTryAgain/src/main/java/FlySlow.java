public class FlySlow implements FlyBehaviour {
    @Override
    public void fly() {
        System.out.println("I Fly Very Slow");
    }
}
