import java.util.ArrayList;
import java.util.List;

public class Ducks {
    List<Duck> duckList = new ArrayList<Duck>();

    public void addDuck(Duck duck){
        duckList.add(duck);
    }

    public Duck findBy(int index){
        return duckList.get(index);
    }
}
