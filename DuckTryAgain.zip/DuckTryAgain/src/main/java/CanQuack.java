public class CanQuack implements QuackBehaviour {
    @Override
    public void Quack() {
        System.out.println("I can Quack");
    }
}
