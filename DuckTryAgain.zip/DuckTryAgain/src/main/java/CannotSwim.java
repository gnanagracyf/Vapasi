public class CannotSwim implements SwimBehaviour {
    @Override
    public void swim() {

    }
}
