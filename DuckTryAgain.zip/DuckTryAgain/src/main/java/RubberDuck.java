import java.security.PublicKey;

public class RubberDuck extends Duck {

    public RubberDuck() {
        flyBehaviour = new CannotFly();
        swimBehaviour = new CanSwim();
    }



}
