public  class Duck {

    String name;
    FlyBehaviour flyBehaviour;
    SwimBehaviour swimBehaviour;

    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }
    public void setFlyBehaviour()
    {
        flyBehaviour.fly();
    }

    public void setSwimBehaviour(){
        swimBehaviour.swim();
    }

//    public void fly(){
//        //System.out.println(this.getClass().getName() +" Flies.");
//        System.out.println(this.getName() +" Flies.");
//
//    }
//
//    public void quack(){
//        //System.out.println(this.getClass().getName() + " Quacks.");
//        System.out.println(this.getName() + " Quacks.");
//    }
//
//    public void swim(){
//        //System.out.println(this.getClass().getName() + " Swims.");
//        System.out.println(this.getName() + " Swims.");
//    }


}
