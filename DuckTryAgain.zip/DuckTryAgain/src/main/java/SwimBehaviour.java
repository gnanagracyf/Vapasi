public interface SwimBehaviour {
    public void swim();
}
