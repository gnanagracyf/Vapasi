public class MarbledDuck extends Duck {
    public MarbledDuck() {
        flyBehaviour = new CannotFly();
        swimBehaviour = new CannotSwim();
    }

}
