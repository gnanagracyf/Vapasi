public class Pond {

    public static void main(String[] args){
        Ducks ducks = new Ducks();
//        Duck duck1 = new Duck();
//        ducks.addDuck(duck1);
//        Duck duck2 = new Duck();
//        ducks.addDuck(duck2);
//        Duck duck3 = new Duck();
//        ducks.addDuck(duck3);
//
//        for (int i = 0; i < ducks.duckList.size(); i++){
//            ducks.duckList.get(i).setName("duck"+ new String(String.valueOf(i)));
//            //ducks.duckList.get(i).fly();
//            //ducks.duckList.get(i).swim();
//            ducks.duckList.get(i).quack();
//        }

        //After inheritance...able to create many varieties of ducks . Also can have many ducks in each variety.
        Duck mallardDuck = new MallardDuck();
        Duck redheadDuck = new RedHeadDuck();
        Duck marbledDuck = new MarbledDuck();
        Duck rubberDuck = new RubberDuck();

        ducks.addDuck(mallardDuck);
        ducks.addDuck(redheadDuck);
        ducks.addDuck(marbledDuck);
        ducks.addDuck(rubberDuck);

        for (int i = 0; i < ducks.duckList.size(); i++){
            System.out.println("Am inside for");
           ducks.duckList.get(i).setName("duck"+ new String(String.valueOf(i)));
            ducks.duckList.get(i).setFlyBehaviour();
            ducks.duckList.get(i).setSwimBehaviour();
            //ducks.duckList.get(i).quack();
        }

        mallardDuck.setName("FirstMallardDuck");
        //mallardDuck.fly(); //can fly fast
        mallardDuck.setFlyBehaviour();
        //mallardDuck.swim(); // but swims slow
        mallardDuck.setSwimBehaviour();
        //mallardDuck.quack();

        redheadDuck.setName("FirstRedHeadDuck");
        //redheadDuck.fly(); //Fly slow
        redheadDuck.setFlyBehaviour();
        //redheadDuck.swim(); // swim fast
        redheadDuck.setSwimBehaviour();
        //redheadDuck.quack();

        marbledDuck.setName("FirstMarbledDuck"); //cannot quake,cannot fly, cannot swim
        marbledDuck.setFlyBehaviour();
        marbledDuck.setSwimBehaviour();

        rubberDuck.setName("FirstRubberDuck"); // can swim and quack but cannot fly
        rubberDuck.setFlyBehaviour();
        rubberDuck.setSwimBehaviour();


    }
}
