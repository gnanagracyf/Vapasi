public class CannotQuack implements QuackBehaviour {
    @Override
    public void Quack() {
        System.out.println("I Cannot Quack");
    }
}
