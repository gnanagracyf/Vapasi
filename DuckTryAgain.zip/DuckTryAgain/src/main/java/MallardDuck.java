public class MallardDuck<flyBehaviour> extends Duck{
    public MallardDuck() {
        flyBehaviour = new FlyFast();
        swimBehaviour = new CanSwim();
    }


}
