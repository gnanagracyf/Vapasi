public interface QuackBehaviour {
    public void Quack();
}
