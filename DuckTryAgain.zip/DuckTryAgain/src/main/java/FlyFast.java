public class FlyFast implements FlyBehaviour {


    @Override
    public void fly() {
        System.out.println("I CAN FLY FASTTTTT");
    }
}
