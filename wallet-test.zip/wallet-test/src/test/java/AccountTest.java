import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class AccountTest {

    @Ignore
    @Test
    public void shouldPutTenRsIntoEmptyAccount() {
        EmailEngine emailEngine = null;
        Account account = new Account(); // Change for this also..include collaborator as outside people will b confused with what constructor to use
        assertEquals(10,account.addMoney(10));
    }

    @Ignore
    @Test
    public void shouldPutTenRsIntoWalletWithMoney(){
        EmailEngine emailEngine = null;
        Account account = new Account();
        account.setMoney(20);

        assertEquals(30,account.addMoney(10));
    }

    @Ignore
    @Test
    public void shouldNotAddNegativeMoneyIntoEmptyAccount(){
        EmailEngine emailEngine = null;
        Account account = new Account();

        assertEquals(0,account.addMoney(-10));
    }

    @Ignore
    @Test
    public void shouldSubtract10NegativeMoneyIntoAccountWithMoney(){
        EmailEngine emailEngine = null;
        Account wallet = new Account();
        wallet.setMoney(10);

        assertEquals(10,wallet.addMoney(-10));
    }

    @Ignore
    @Test
    public void shouldTake10RsFromAccountWithMoney() throws InsufficinetBalanceException {
        EmailEngine emailEngine = null;
        Account wallet = new Account();
        wallet.setMoney(10);
        assertEquals(0,wallet.takeMoney(10));
    }

//    @Rule
//    public ExpectedException thrown = ExpectedException.none();
//
//    @Test
//    public void shouldThrowExceptionWhenTaking10RsFromEmptyWallet() throws InsufficinetBalanceException {
//        Account wallet = new Account();
//        thrown.expect(InsufficinetBalanceException.class);
//        thrown.expectMessage("Balance Cannot Be Null");
//        wallet.takeMoney(10);
//    }


    @Test
    public void shouldSendEmailWhenOverDrafted(){
        //EmailEngine email = null;
        //EmailEngine emailEngine = mock(EmailEngine.class);
        AccountOwner accountOwner = mock(AccountOwner.class);
        Auditor auditor = mock(Auditor.class);
        Account account = new Account(10, new AccountOwner("GG"));

        account.setMoney(10);
        assertEquals(-90,account.takeMoney(100));
        //verify(emailEngine).sendEmail(eq("OverDraft"));
        //verify(email).sendEmail("Hi");
        verify(accountOwner).getNotify();
        verify(auditor).getNotified();

    }

}
