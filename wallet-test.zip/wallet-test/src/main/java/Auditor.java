public class Auditor implements  Observer{


    @Override
    public void getUpdates() {

    }


    @Override
    public void subscribe() {

    }

    @Override
    public void unsubscribe() {

    }
}
