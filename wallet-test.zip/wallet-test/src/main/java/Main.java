public class Main {

    public static void main(String[] args){
        Account account1 = new Account(10);

        Auditor auditor1 = new Auditor();
        AccountOwner accountOwner = new AccountOwner();

        Observer ob1 = new Auditor();
        Observer ob2 = new AccountOwner();

        ob1.subscribe();
        ob2.subscribe();

        ob1.Notification();
        ob2.Notification();

        ob1.unsubscribe();
        ob2.unsubscribe();



    }
}
