public class EmailEngine {
    public void sendEmail(String s){

    }
}
