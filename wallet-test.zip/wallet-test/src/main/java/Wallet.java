public class Wallet {

    private int money;

    public int addMoney(int moneyToBeAdded) {
        if ( moneyToBeAdded > 0 )
            money += moneyToBeAdded;
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int takeMoney(int money) throws InsufficinetBalanceException {

        int balance;
        balance = this.money - money;
        if ( balance <= 0)
            throw new InsufficinetBalanceException("Balance Cannot Be Null");

        return balance;
    }


}

