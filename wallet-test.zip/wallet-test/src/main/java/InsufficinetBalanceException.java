public class InsufficinetBalanceException extends Throwable {
    public InsufficinetBalanceException(String message){
        super(message);
    }

}
