public class AccountOwner implements Observer{


    @Override
    public void getUpdates() {

    }


    @Override
    public void subscribe() {

    }

    @Override
    public void unsubscribe() {

    }
}
