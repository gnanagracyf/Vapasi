public interface Observer {
    public void getUpdates();
    //public void Notification();
    public void subscribe();
    public void unsubscribe();
}
