public class Account {

    private int money;
    Observer observer;

    public Account(int money){
        this.money = money;
    }

    public int addMoney(int moneyToBeAdded) {
        int balance = 0;
        balance = this.money + moneyToBeAdded;
        return balance;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public int takeMoney(int money) {
        int balance;
        balance = this.money - money;
        if ( balance < 0) {
           observer.getUpdates();

        }
        return balance;
    }

    public static void main(String[] args){
        Account a = new Account(10);
        a.takeMoney(1000);
    }
}
