$('#locationDdl').on('change', function() {
    $.cookie("location",this.value);
    window.location.href = "/";
});

$('form#signIn').ajaxForm({
    success: function(response, statusText, xhr, $form)  {
        if(response == null || response.name == null) {
            $('form .error').replaceWith( "<p class='alert alert-danger'>Email and password do not match</p>");
        } else {
            // response is JSON version of the Spring's Authentication
           window.location.href="/";
        }
    },
    error: function(response, statusText, error, $form)  {
        if(response != null && response.message == "authentication-failure") {
            $('form .error').replaceWith( "<p class='alert alert-danger'>Email and password do not match</p>");
        }
    }
});

$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results==null) {
       return null;
    }
    return decodeURI(results[1]) || 0;
}
$( document ).ready(function() {
    var registration=$.urlParam('registration');
    if(registration=="success")
    {
        $('#loginModal').modal('show');
    }
});
