INSERT INTO theaters values (1, 'PVR Cinemas chennai',1);
INSERT INTO theaters values (2, 'SPI chennai' ,1);
INSERT INTO theaters values (3, 'INOX chennai',2);
INSERT INTO theaters values (4, 'SPI trichy',2);
INSERT INTO theaters values (5, 'PVR Madurai',3);