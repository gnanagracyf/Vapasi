INSERT INTO users values (1, 'Saraswathy','saraswathy@gmail.com', '$2a$04$AtAfxURHds2TNiuPJ0Ss0eyp6htan2rxToRgjzDehN4aoIixeb4wC');
INSERT INTO users values (2, 'Gracy','gracy.f@gmail.com', '$2a$04$AtAfxURHds2TNiuPJ0Ss0eyp6htan2rxToRgjzDehN4aoIixeb4wC');
