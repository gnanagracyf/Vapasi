CREATE TABLE locations (
    id serial PRIMARY KEY,
    name VARCHAR (50) NOT NULL
)