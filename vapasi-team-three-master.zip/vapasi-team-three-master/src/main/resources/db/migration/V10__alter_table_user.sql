ALTER TABLE users
 ADD location_id int REFERENCES locations(id) DEFAULT null;