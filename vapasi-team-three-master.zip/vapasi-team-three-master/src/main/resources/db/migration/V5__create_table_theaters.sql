CREATE TABLE theaters (
    id serial PRIMARY KEY,
    name VARCHAR (60) NOT NULL,
    location_id int REFERENCES locations(id)
)