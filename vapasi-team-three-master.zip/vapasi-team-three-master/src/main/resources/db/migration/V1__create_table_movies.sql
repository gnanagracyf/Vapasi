CREATE TABLE movies (
    id serial PRIMARY KEY,
    name VARCHAR (50) NOT NULL,
    image_name VARCHAR (50) NOT NULL,
    sound_track VARCHAR (50) NOT NULL,
    release_date date  NOT NULL
)