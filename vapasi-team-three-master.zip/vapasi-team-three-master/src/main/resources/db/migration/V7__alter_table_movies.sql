ALTER TABLE movies
  ADD theater_id int REFERENCES theaters(id);