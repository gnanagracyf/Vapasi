INSERT INTO locations values (1, 'chennai');
INSERT INTO locations values (2,'trichy');
INSERT INTO locations values (3,'madurai');