package com.just_cinemas.repository;

import com.just_cinemas.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MovieRespository extends JpaRepository<Movie,Integer> {
   List<Movie> findAllByOrderByNameAsc();
   List<Movie> findAllByTheaterLocationName(String location);
}
