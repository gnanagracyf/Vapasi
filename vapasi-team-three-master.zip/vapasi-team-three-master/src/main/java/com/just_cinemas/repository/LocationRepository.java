package com.just_cinemas.repository;

import com.just_cinemas.model.Location;
import com.just_cinemas.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location, Integer> {
    Location findAllByName(String name);
}
