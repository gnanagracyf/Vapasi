package com.just_cinemas.model;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "movies")

public class Movie {
        @Id
        @Column
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Getter
        private int id;

        @Column
        @Getter
        private String name;

        @Column
        @Getter
        private String imageName;

        @Column
        @Getter
        private String soundTrack;

        @Column
        @Getter
        private Date releaseDate;

        @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
        @JoinColumn(name="theater_id", referencedColumnName = "id", insertable = false, updatable = false)
        @Getter
        private Theater theater;

//        @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//        @JoinColumn(name="language_id", referencedColumnName = "id", insertable = false, updatable = false)
//        private Language language;

        public Movie() {
        }

        public Movie(int id, String name, String imageName, String soundTrack, Date releaseDate,  Theater theate) {
                this.id = id;
                this.name = name;
                this.imageName = imageName;
                this.soundTrack = soundTrack;
                this.releaseDate = releaseDate;
                this.theater = theater;
//                this.language = language;
        }


}
