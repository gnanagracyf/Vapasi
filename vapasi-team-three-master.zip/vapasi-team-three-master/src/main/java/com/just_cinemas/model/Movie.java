package com.just_cinemas.model;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "movies")
@Getter
public class Movie {
        @Id
        @Column
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int id;

        @Column
        private String name;

        @Column
        private String imageName;

        @Column
        private String soundTrack;

        @Column
        private Date releaseDate;

        @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
        @JoinColumn(name="theater_id", referencedColumnName = "id", insertable = false, updatable = false)
        private Theater theater;

//        @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//        @JoinColumn(name="language_id", referencedColumnName = "id", insertable = false, updatable = false)
//        private Language language;

        public Movie() {
        }

        public Movie(int id, String name, String imageName, String soundTrack, Date releaseDate,  Theater theate) {
                this.id = id;
                this.name = name;
                this.imageName = imageName;
                this.soundTrack = soundTrack;
                this.releaseDate = releaseDate;
                this.theater = theater;
//                this.language = language;
        }


}
