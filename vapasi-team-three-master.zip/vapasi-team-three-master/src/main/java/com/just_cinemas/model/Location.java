package com.just_cinemas.model;

import lombok.Getter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "locations")
@Getter
public class Location {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    @Getter
    private String name;

    @OneToMany(targetEntity= Theater.class, mappedBy="location")
    private List<Theater> theater ;

}
