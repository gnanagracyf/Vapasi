package com.just_cinemas.model;

import lombok.Getter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "locations")

public class Location {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    private int id;

    @Column
    @Getter
    private String name;

    @OneToMany(mappedBy = "location")
    @Getter
    private List<User> users;

    @OneToMany(targetEntity= Theater.class, mappedBy="location")
    @Getter
    private List<Theater> theater ;

}
