package com.just_cinemas.model;

import lombok.Getter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "theaters")

public class Theater {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    private int id;

    @Column
    @Getter
    private String name;


    @Getter
    @OneToMany(targetEntity= Movie.class, mappedBy="theater")
    private List<Movie> movie ;

    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name="location_id", referencedColumnName = "id", insertable = false, updatable = false)
    @Getter
    private Location location;



}
