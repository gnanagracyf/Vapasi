package com.just_cinemas.controller;

import com.just_cinemas.dto.UserDto;
import com.just_cinemas.model.User;
import com.just_cinemas.repository.UserRepository;
import com.just_cinemas.service.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import flexjson.JSONSerializer;

import javax.validation.Valid;


@Controller
public class UserController {
    @Autowired
    UserRepository userRepository;

    @Autowired
    UserDetailsServiceImpl userDetailsService;

    @Autowired
    @Qualifier("authenticationManagerBean")
    AuthenticationManager authenticationManager;

    public HttpHeaders getJsonHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json");
        return headers;
    }

    @GetMapping("/login")
    public String login()
    {
        return "login";
    }

    @GetMapping("/authentication-failure")
    public ResponseEntity<String> apiAuthenticationFailure() {
        return new ResponseEntity<String>("{\"success\" : false, \"message\" : \"authentication-failure\"}", getJsonHeaders(), HttpStatus.OK);
    }

    @GetMapping("/authentication-success")
    public ResponseEntity<String> apiAuthenticationSuccess() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userJson = new JSONSerializer().serialize(authentication);
        return new ResponseEntity<String>(userJson, getJsonHeaders(), HttpStatus.OK);
    }

    @GetMapping("/registration")
    public String getRegistration(UserDto userDto,Model model)
    {
        return "registration";
    }

    @PostMapping("/registration")
    public String postRegistration(@Valid UserDto userDto, BindingResult bindingResult){
        User existing = userRepository.findByEmail(userDto.getEmail());
        if (existing != null) {
            bindingResult.rejectValue("email", null, "There is already an account registered with that email");
        }
        if (bindingResult.hasErrors()){
            return "registration";
        }
        userRepository.save(userDto.convertToUser());
        return "redirect:/?registration=success";
    }
}
