package com.just_cinemas.controller;

import com.just_cinemas.repository.LocationRepository;
import com.just_cinemas.repository.MovieRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

@Controller
public class MoviesController {
    @Autowired
    MovieRespository movieRespository;

    @Autowired
    LocationRepository locationRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @GetMapping("/")
    public String getMovies(Model model, HttpServletRequest request){
        String userLocationCookie = "Chennai";
        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("location")) {
                    userLocationCookie = cookie.getValue();
                }
            }
        }

        model.addAttribute("movies", movieRespository.findAllByTheaterLocationName(userLocationCookie.toLowerCase()));
        model.addAttribute("locationList",locationRepository.findAll());
        model.addAttribute("userLocationCookie",userLocationCookie);

        return "index";
    }

    @GetMapping("/about-us")
    public String getAboutUs()
    {
        return "about_us";
    }

    @GetMapping("/terms-and-conditions")
    public String getTerms()
    {
        return "terms_conditions";
    }
}
