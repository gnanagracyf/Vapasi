package com.just_cinemas.controller;

import com.just_cinemas.model.User;
import com.just_cinemas.repository.LocationRepository;
import com.just_cinemas.repository.MovieRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

@Controller
public class MoviesController {
    @Autowired
    MovieRespository movieRespository;

    @Autowired
    LocationRepository locationRepository;

    @PersistenceContext
    private EntityManager entityManager;

    String  userLocationCookie = "Chennai";


    @GetMapping(path = "/")
    public String getMovies(Model model, HttpServletRequest request){

        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("location")) {
                    userLocationCookie = cookie.getValue();
                }
            }
        }

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User currentUser=new User();
        if(principal!="anonymousUser")
            currentUser=(User)principal;
        else
            currentUser=null;

        if (currentUser != null && currentUser.getLocation()!= null )
            userLocationCookie = currentUser.getLocation().getName();

        if(currentUser!=null && currentUser.getLocation()==null)
            model.addAttribute("setLocationFlag",true);
        else
            model.addAttribute("setLocationFlag",false);


        model.addAttribute("movies", movieRespository.findAllByTheaterLocationName(userLocationCookie.toLowerCase()));
        model.addAttribute("locationList",locationRepository.findAll());
        model.addAttribute("userLocationCookie",userLocationCookie);

        return "index";
    }

    @GetMapping("/about-us")
    public String getAboutUs()
    {
        return "about_us";
    }

    @GetMapping("/terms-and-conditions")
    public String getTerms()
    {
        return "terms_conditions";
    }
}
