package com.just_cinemas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JustCinemas {

	public static void main(String[] args) {
		SpringApplication.run(JustCinemas.class, args);
	}

}
