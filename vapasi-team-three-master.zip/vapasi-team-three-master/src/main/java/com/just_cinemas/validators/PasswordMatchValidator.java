package com.just_cinemas.validators;
import com.just_cinemas.dto.UserDto;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


public class PasswordMatchValidator implements ConstraintValidator<PasswordMatch,UserDto> {

    @Override
    public boolean isValid(UserDto userDto, ConstraintValidatorContext context) {
        return (userDto.getPassword().equals(userDto.getConfirmPassword()));
    }
}

