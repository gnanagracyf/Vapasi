package com.just_cinemas.validators;

import ch.qos.logback.classic.gaffer.PropertyUtil;
import com.just_cinemas.dto.UserDto;
import org.thymeleaf.util.ObjectUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.Field;

public class PasswordMatchValidator implements ConstraintValidator<PasswordMatch,Object> {

    private String password;
    private String confirmPassword;

    @Override
    public void initialize(final PasswordMatch constraintAnnotation) {
        password = constraintAnnotation.password();
        confirmPassword = constraintAnnotation.confirmPassword();
    }

    @Override
    public boolean isValid(Object userDto, ConstraintValidatorContext context) {
        UserDto userDtoCopy=(UserDto) userDto;
        return (userDtoCopy.getPassword().equals(userDtoCopy.getConfirmPassword()));
    }
}

