package com.just_cinemas.service;

import com.just_cinemas.model.User;
import com.just_cinemas.repository.UserRepository;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.junit.Assert;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class UserDetailsServiceImplTest {
    @InjectMocks
    UserDetailsServiceImpl userDetailsServiceImpl;

    @Mock
    UserRepository userRepository;

    @Test
    public void testLoadUserByName(){
        String email = "gracy.f@gmail.com";
        User user = new User(email,"!@#$!@#$!@#$","Gracy");
        Mockito.when(userRepository.findByEmail(email)).thenReturn(user);
        assertEquals(  user  , userDetailsServiceImpl.loadUserByUsername("gracy.f@gmail.com"));
    }

    @Test(expected = UsernameNotFoundException.class)
    public void testLoadUserByNameWhenEmailDontExists(){
        String email = "kani@gmail.com";
        Mockito.when(userRepository.findByEmail(email)).thenReturn(null);
        userDetailsServiceImpl.loadUserByUsername(email);
    }
}