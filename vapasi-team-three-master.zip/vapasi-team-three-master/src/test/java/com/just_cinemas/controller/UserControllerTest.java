package com.just_cinemas.controller;

import com.just_cinemas.dto.UserDto;
import com.just_cinemas.model.User;
import com.just_cinemas.repository.UserRepository;
import com.just_cinemas.service.UserDetailsServiceImpl;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.validation.BindingResult;

import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import java.util.Set;

import static org.mockito.Mockito.*;



@RunWith(MockitoJUnitRunner.Silent.class)
public class UserControllerTest extends TestCase {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    UserController userController;

    @Mock
    BindingResult bindingResult;

    @Mock
    UserDetailsServiceImpl userDetailsService;

    private Validator validator;

    @Before
    public void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    public void testPostRegistrationIfUserIsCreated() {
        UserDto userDto=new UserDto("Test User 1","testuser@gmail.com","12345678","12345678");
        Assert.assertEquals("redirect:/?registration=success", userController.postRegistration(userDto,bindingResult));
        ArgumentCaptor<User> userArgumentCaptor=ArgumentCaptor.forClass(User.class);
        verify(userRepository).save(userArgumentCaptor.capture());
        assertEquals("testuser@gmail.com",userArgumentCaptor.getValue().getEmail());
    }

    @Test
    public void testPostRegistrationShowErrorIfPasswordAndConfirmPasswordAreNotSame(){
        UserDto userDto=new UserDto("Test User 1","testuser@gmail.com","12345678","123458970");
        Set violations=validator.validate(userDto);
        assertFalse(violations.isEmpty());
    }
}