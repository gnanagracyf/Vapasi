package com.just_cinemas.controller;

import com.just_cinemas.model.Location;
import com.just_cinemas.model.Movie;
import com.just_cinemas.repository.LocationRepository;
import com.just_cinemas.repository.MovieRespository;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.OngoingStubbing;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.ui.Model;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(MockitoJUnitRunner.Silent.class)
public class MoviesControllerTest extends TestCase {

    @InjectMocks
    MoviesController moviesController;

    @Mock
    MovieRespository movieRespository;

    @Mock
    Model model;

    @Mock
    HttpServletRequest request;

    @Mock
    Movie movie1, movie2;

    @Mock
    Location mockLocation1, mockLocation2;

    @Mock
    Cookie cookies;


    @Mock
    LocationRepository locationRepository;

    @Test
    public void testGetMovies() throws Exception {
        List<Movie> movies = new ArrayList<>();
        movies.add(movie1);
        movies.add(movie2);
        String location = "chennai";

        List<Location> locationList = new ArrayList<>();
        locationList.add(mockLocation1);
        locationList.add(mockLocation2);

        List<Object> objlist = new ArrayList<>();
        objlist.add(movies);
        objlist.add(locationList);

        Cookie[] cookie = new Cookie[0];
        String getcookievalue = "";
        when(request.getCookies()).thenReturn(cookie);
        when(cookies.getName()).thenReturn(location);
        when(cookies.getValue()).thenReturn(location);
        when(movieRespository.findAllByTheaterLocationName(location)).thenReturn(movies);
        when(locationRepository.findAll()).thenReturn(locationList);
        Assert.assertEquals("index", moviesController.getMovies(model, request));
        verify(model, times(3)).addAttribute(any(),any());

    }

}
