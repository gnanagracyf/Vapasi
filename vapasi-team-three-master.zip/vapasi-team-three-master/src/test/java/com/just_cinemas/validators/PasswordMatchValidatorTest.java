package com.just_cinemas.validators;

import junit.framework.TestCase;

public class PasswordMatchValidatorTest extends TestCase {

    public void testIsValid() {

    }
}