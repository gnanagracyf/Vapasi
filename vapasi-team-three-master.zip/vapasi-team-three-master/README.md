# Vapasi Team Three

To set up Postgresql in dev env (Mac)
-------------------------------------
- brew update
- brew install postgresql

- Initialize the physical space on your hard-disk to allocate databases. To do this, create a default postgres database 
    -   initdb /usr/local/var/postgres
- Start pg
    - pg_ctl -D /usr/local/var/postgres start
- psql postgres
- create user <username> with encrypted password ‘password’;
- login as the new user (psql postgres <username>)
- CREATE DATABASE just_cinemas;
