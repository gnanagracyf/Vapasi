class Twofer {
    String twofer(String name) {
            if (name == null)
                name = "you";
            else
                name = name;
            return ( "One for "+ name +  ", one for me.");


        }
    }

